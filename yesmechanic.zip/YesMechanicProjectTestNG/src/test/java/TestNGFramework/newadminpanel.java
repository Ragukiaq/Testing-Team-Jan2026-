package TestNGFramework;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class newadminpanel {
	WebDriver driver;

	@BeforeTest
	public void InitialiseBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@AfterTest
	public void Teardown() {

		driver.quit();
	}

	@Test

	public void LoginPage() throws Exception {
		driver.get("https://admin.yesmechanic.co/login");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		Thread.sleep(5000);
	}
	@Test(priority=0)
	public void dashboard() throws Exception {
		driver.findElement(By.xpath("//span[normalize-space()='Dashboard']")).click();
		Thread.sleep(5000);
	}
	@Test(priority=1)
	public void servicerequest() throws Exception {
		driver.findElement(By.xpath("//a[@href='/bookings']//div[@class='text-xl']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[normalize-space()='Assigned']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Search by ID or Name...']")).sendKeys("Engine");
		Thread.sleep(1000);

	}
	@Test(priority=2)
	public void schedulerequest() throws Exception {
		driver.findElement(By.xpath("//a[@href='/request-queue']//div[@class='text-xl']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[.//text()[contains(.,'Scheduled')]]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//*[name()='svg'][@class='w-5 h-5'])[1]")).click();
		Thread.sleep(1000);
	}

	@Test(priority=3)
	public void orders() throws Exception {
		driver.findElement(By.xpath("//a[@href='/order']//div[@class='text-xl']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[normalize-space()='Completed orders']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Search by ID or Name...']")).sendKeys("vl9843");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@type='date']")).click();
		Thread.sleep(1000);

	}

	@Test(priority=4)
	public void partner() throws Exception {
		driver.findElement(By.xpath("//a[@href='/service']//div[@class='text-xl']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@title='Search']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("sourabh");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("jain");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Company Name']")).sendKeys("abcmechanic");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Phone Number']")).sendKeys("9677240419");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='ex 600001']")).sendKeys("603203");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Address Line 1']")).sendKeys("480");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='Address Line 2']")).sendKeys("mintstreet");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//select[@name='contact_info.state']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//select[@name='contact_info.city']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='regNo']")).sendKeys("tn18bc4096");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Aadhar no']")).sendKeys("7915028085541");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='PAN no']")).sendKeys("edpe7234567");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='GST No']")).sendKeys("gstin540987654");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[normalize-space()='Cancel']")).click();
		Thread.sleep(5000);
		
}
	@Test(priority=5)
	public void jobcards() throws Exception {
		driver.findElement(By.xpath("//span[normalize-space()='Job Cards']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[normalize-space()='History']")).click();
		Thread.sleep(1000);
	}
	@Test(priority=6)
	public void citymanagement() throws Exception {
		driver.findElement(By.xpath("//a[@href='/city']//div[@class='text-xl']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='Search by city name']")).sendKeys("chennai", Keys.ENTER);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='New City']")).sendKeys("chennai");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Pincode']")).sendKeys("600053");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//button[contains(text(),'View')])[2]")).click();
		Thread.sleep(3000);
	}
	@Test(priority=7)
	public void vehicle() throws Exception {
		driver.findElement(By.xpath("//a[@href='/vehicle']//div[@class='text-xl']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='flex mt-10']//*[name()='svg']")).click();
		Thread.sleep(5000);
	}
	@Test
	public void sos() throws Exception {
		driver.findElement(By.xpath("//a[@href='/sos']//div[@class='text-xl']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[normalize-space()='Not Started']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[normalize-space()='In Progress']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[normalize-space()='Completed']")).click();
		Thread.sleep(5000);
	}}
