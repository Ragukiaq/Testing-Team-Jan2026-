package TestNGFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class user {
    WebDriver driver;

    @BeforeTest
    public void InitialiseBrowser() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterTest
    public void Teardown() {
        driver.quit();
    }

    @Test (priority=1)
    public void LoginPage() throws Exception {
        driver.get("https://sms-userpanel.netlify.app/");
        Thread.sleep(5000);
    }
    @Test(priority=2)
    public void login () throws Exception {
    	 driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
         Thread.sleep(4000);
         driver.findElement(By.xpath("//input[@id='phone']")).sendKeys("8610966352");
         Thread.sleep(2000); 
         driver.findElement(By.xpath("//button[@type='submit']")).click();
         Thread.sleep(2000);
         driver.findElement(By.xpath("(//input[@type='text'])[2]")).sendKeys("0");
         Thread.sleep(2000); 
         driver.findElement(By.xpath("(//input[@type='text'])[3]")).sendKeys("0");
         Thread.sleep(2000);
         driver.findElement(By.xpath("(//input[@type='text'])[4]")).sendKeys("0");
         Thread.sleep(2000);
         driver.findElement(By.xpath("(//input[@type='text'])[5]")).sendKeys("0");
         Thread.sleep(2000);
         driver.findElement(By.xpath("(//input[@type='text'])[6]")).sendKeys("0");
         Thread.sleep(2000);
         driver.findElement(By.xpath("(//input[@type='text'])[7]")).sendKeys("0");
         Thread.sleep(2000);
         driver.findElement(By.xpath("//button[normalize-space()='Verify OTP']")).click();
         Thread.sleep(2000);
         
    }
   
    
    
    @Test (priority=3)
    public void offer() throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Offers']")).click();
        Thread.sleep(5000);
    
}
    
    
    @Test(priority=4)
    public void Enquiry() throws Exception {
        driver.findElement(By.xpath("//button[normalize-space()='Enquiry']")).click();
        Thread.sleep(5000);

    }
   
    
    
    @Test(priority=5)
    public void service() throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Services']")).click();
        Thread.sleep(4000);
    }
    public void servives () throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Services']")).click();
        Thread.sleep(4000);
    
        driver.findElement(By.xpath("//span[@class='text-sm font-semibold whitespace-nowrap transition-all duration-300'][normalize-space()='Enginee']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("(//button[contains(text(),'Add to Cart')])[1]")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//button[normalize-space()='Pre-Booked Service']")).click();
        Thread.sleep(2000);
        
        
        driver.findElement(By.xpath("//select[@id='cars']")).click();
        Thread.sleep(2000);
        
        
        driver.findElement(By.xpath("//input[@value='08/25/2025']")).click();
        Thread.sleep(2000);
        
        
        driver.findElement(By.xpath("//input[@value='11:30'")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//input[@value='17:30'")).click();
        Thread.sleep(2000);
     
}
    @Test(priority=6)
    public void spareparts() throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Spare Parts']")).click();
        Thread.sleep(4000);
    }
    
    
    
    @Test(priority=7)
    public void bookingcart() throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Booking Cart']")).click();
        Thread.sleep(4000);
    }
    
    
    @Test(priority=8)
    public void notification() throws Exception {
        driver.findElement(By.xpath("//button[@aria-label='Notifications']")).click();
        Thread.sleep(4000);

}
    
    
    
    @Test(priority=9)
    public void bookings() throws Exception {
        driver.findElement(By.xpath("//a[normalize-space()='Bookings']")).click();
        Thread.sleep(4000);
    }
    
}  
    
   
    

