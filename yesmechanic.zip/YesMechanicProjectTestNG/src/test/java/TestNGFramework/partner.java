package TestNGFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class partner {
    WebDriver driver;

    @BeforeTest
    public void InitialiseBrowser() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterTest
    public void Teardown() {
        driver.quit();
    }

    @Test
    public void LoginPage() throws Exception {
        driver.get("https://sms-partnerpannel.netlify.app/");
        Thread.sleep(5000);  // Wait for page to load

        driver.findElement(By.xpath("//input[@placeholder='Enter your email']")).sendKeys("admin@gmail.com");
        Thread.sleep(2000);  // Shorter delay since input is quick

        driver.findElement(By.xpath("//input[@placeholder='Enter your password']")).sendKeys("8610966352");
        Thread.sleep(2000);

        driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
        Thread.sleep(6000);  // Wait for redirect/dashboard to load
    }

    @Test(priority=0)
    public void dashboard() throws Exception {
        Thread.sleep(2000);  // Ensure dashboard is ready
        driver.findElement(By.xpath("//a[@href='/']//div[@class='text-xl']")).click();
        Thread.sleep(4000);
    }

    @Test(priority=1)
    public void settings() throws Exception {
        driver.findElement(By.xpath("//a[@href='/settings']//div[@class='text-xl']")).click();
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//button[normalize-space()='Account Settings']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//button[normalize-space()='About us']")).click();
        Thread.sleep(2000);
        
    }
    
    @Test(priority=2)
    public void announcement() throws Exception {
        driver.findElement(By.xpath("//a[@href='/announcement']//div[@class='text-xl']")).click();
        Thread.sleep(5000);
        

        driver.findElement(By.xpath("//li[normalize-space()='All']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//li[normalize-space()='General']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//li[normalize-space()='Offeres']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//li[normalize-space()='Services']")).click();
        Thread.sleep(2000);
        
    }
    @Test (priority=3)
    public void Enquiry() throws Exception {
        driver.findElement(By.xpath("//a[@href='/enquiry-page']//div[@class='text-xl']")).click();
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//input[contains(@placeholder,'Enter your name')]")).sendKeys("service",Keys.ENTER);
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@placeholder='Enter phone number']")).sendKeys("01236549");
		Thread.sleep(3000); 
		
		 driver.findElement(By.xpath("//textarea[@placeholder='Describe your issue or question...']")).sendKeys("welcome",Keys.ENTER);
	     Thread.sleep(3000);
			
    }
    @Test(priority=4)
    public void Notification() throws Exception {
        driver.findElement(By.xpath("//a[@href='/notifications']//div[@class='text-xl']")).click();
        Thread.sleep(5000); 
        
        driver.findElement(By.xpath("//button[normalize-space()='All']")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[normalize-space()='Read']")).click();
		Thread.sleep(2000);
}

    @Test(priority=5)
    public void  notifications() throws Exception {
        driver.findElement(By.xpath("//button[@aria-label='Notifications']//img")).click();
        Thread.sleep(5000); 
}

    @Test
    public void sparepart() throws Exception {
        driver.findElement(By.xpath("//a[contains(@href,'/spare-parts')]//div[contains(@class,'text-xl')]")).click();
        Thread.sleep(4000);

        driver.findElement(By.xpath("//button[normalize-space()='All Categories']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//span[normalize-space()='tyres']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//span[normalize-space()='Engine']")).click();
        Thread.sleep(2000);

    }

    @Test(priority=6)
    public void jobcards() throws Exception {
        driver.findElement(By.xpath("//a[@href='/bookings']//div[@class='text-xl']")).click();
        Thread.sleep(2000);
    }

    @Test(priority=7)
    public void servicerequest() throws Exception {
        driver.findElement(By.xpath("//a[@href='/service']")).click();
        Thread.sleep(2000);
    }

    @Test(priority=8)
    public void billing() throws Exception {
        driver.findElement(By.xpath("//a[@href='/Billing']//div[@class='text-xl']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//button[normalize-space()='View History']")).click();
        Thread.sleep(2000);
    }

    @Test(priority=9)
    public void servicercatalogue() throws Exception {
        driver.findElement(By.xpath("//a[@href='/servicecatList']//div[@class='text-xl']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//span[normalize-space()='Add Category']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@placeholder='Enter category name']")).sendKeys("engine oil service");
        Thread.sleep(2000);
    }


    
}
    

